PennController.ResetPrefix(null);                               //shorten command names (keep this line here)
PennController.DebugOff()
var showProgressBar = false;
//// Set the order of the whole experiment ////
Sequence("intro", "PracticeStart", "practice", "PracticeEnd", rshuffle("filler","completion"), "send", "bye","counter");


//// Welcome page ////
PennController("intro",
    newHtml("intro", "Introduction.html")
        .log()
        .print()
    ,
    newText("startText", "<p><h2>परीक्षण शुरू करने के लिए बटन दबाएं  </h2></p>")
        .center()
        .print()
    ,
    newButton("start", "<big><b>Start</b></big>")
//        .settings.before(getText("startText"))
        .size(200, 50)
        .center()
        .cssContainer("vertical-align", "middle")
        .print()
        .wait(getHtml("intro")
            .test.complete()
                .failure(getHtml("intro")
                    .warn()))
);


//// The experiment itself ////
newTrial("PracticeStart",
    newButton("button", "<big><b>परीक्षण शुरू करने से पहले थोड़ा अभ्यास कर लेते हैं।</b></big>")
        .size(300, 60)
        .print()
        .wait()
        );
newTrial("PracticeEnd",
    newButton("button", "<big><b>अभ्यास समाप्त हुआ। अगर आपको कोई प्रश्न हो तो आप परीक्षक से पूछ सकते हैं। आगे बढ़ने के लिए बटन दबाएँ।</b></big>")
        .size(400, 60)
        .print()
        .wait()
        );
Template("ExpSentences.csv", row => 
    newTrial("completion",
        newTimer(250)
            .start()
            .wait()
                ,
        newText("Sentence", row.Sentence)
        .center()
        .cssContainer({"margin-right":"2em"})
        .settings.css("font-size", "2em")
        .print()
                ,
        newTextInput("answer")
        .settings.before(getText("Sentence"))
        .log("validate")
        .lines(1)
        .settings.css("font-size","2em")
        .cssContainer("display","inline")
        .print()
        .wait(getTextInput("answer").testNot.text("") )
                )
        .log("Sentence", row.Sentence)                  //add these three columns to the results lines of these Template-based trials
        .log("Condition", row.Condition)
        .log("Item Number", row.ItemNumber)
//                .log("ID", getVar("ID"))
        );
        
Template("FillerSentences.csv", row => 
    newTrial("filler",
        newTimer(250)
            .start()
            .wait()
            ,
        newText("Sentence", row.Sentence)
            .center()
            .cssContainer({"margin-right":"2em"})
            .settings.css("font-size", "2em")
            .print()
            ,
        newTextInput("answer")
            .settings.before(getText("Sentence"))
            .log("validate")
            .lines(1)
            .settings.css("font-size","2em")
            .cssContainer("display","inline")
            .print()
            .wait(getTextInput("answer").testNot.text("") )
            )
            .log("Sentence", row.Sentence)                  //add these three columns to the results lines of these Template-based trials
            .log("Condition", row.Condition)
            .log("Item Number", row.ItemNumber)
//                .log("ID", getVar("ID"))
    );
Template("PracticeItems.csv", row => 
    newTrial("practice",
        newTimer(250)
            .start()
            .wait()
            ,
        newText("Sentence", row.Sentence)
                .center()
                .cssContainer({"margin-right":"2em"})
                .settings.css("font-size", "2em")
                .print()
            ,
        newTextInput("answer")
                .settings.before(getText("Sentence"))
                .log("validate")
                .lines(1)
                .settings.css("font-size","2em")
                .cssContainer("display","inline")
                .print()
                .wait(getTextInput("answer").testNot.text("") )
            )
        .log("Sentence", row.Sentence)                  //add these three columns to the results lines of these Template-based trials
        .log("Condition", row.Condition)
        .log("Item Number", row.ItemNumber)
//                .log("ID", getVar("ID"))
        );
SendResults("send");
    
//// Last screen (after the experiment is done) ////
newTrial("bye"
    ,
    newText("<big><b>परीक्षण में भाग लेने के लिए धन्यवाद।</big></b>")
        .print()
    ,
    newButton()
        .wait()                                                 // Wait for a click on a non-displayed button = wait here forever
)
.setOption("countsForProgressBar", false );
// Make sure the progress bar is full upon reaching this last (non-)trial